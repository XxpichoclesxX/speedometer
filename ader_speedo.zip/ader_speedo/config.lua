Config = {}

Config['TickTime'] = 50 -- Refresh time while not in the vehicle
