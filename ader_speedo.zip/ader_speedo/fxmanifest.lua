fx_version 'adamant'

game 'gta5'

author 'Ader#6491'
description 'Ader Standalone Speedometer'
version '1.0.0'

ui_page 'html/index.html'

files {
	'html/index.html',
	'html/index.js',
	'html/style.css'
}

client_scripts {
	'client/main.lua',
	'config.lua'
}
